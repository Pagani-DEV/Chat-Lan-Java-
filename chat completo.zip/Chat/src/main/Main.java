package main;

import janelas.LoginFrame;

public class Main {
    public static void main(String[] args) {
        
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }
}
